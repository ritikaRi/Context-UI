sap.ui.define([
	"ns/cm/test/unit/controller/Home.controller"
], function () {
	"use strict";
});