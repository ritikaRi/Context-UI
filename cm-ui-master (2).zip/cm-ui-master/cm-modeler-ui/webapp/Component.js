sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"], function (AppComponent) {
	return AppComponent.extend("sap.iot.ua.modeler.Component", {
		metadata: {
			"manifest": "json"
		}
	});
});