# cm-ui

represented in PPMS via [CONTENT-MGR-DATA-MOD-UI 1.0 ](https://i7p.wdf.sap.corp/ppmslight/#/details/cv/73555000100200012233/overview)

* #### PileLine in foundation01:
1- [CI Pipeline for cm-ui Pipeline](https://foundation01.codepipes.wdf.sap.corp/job/foundation01/view/CI%20Pipeline%20for%20cm-ui%20Pipeline/)

2-[Hotfix Pipeline for cm-ui Pipeline](https://foundation01.codepipes.wdf.sap.corp/job/foundation01/view/Hotfix%20Pipeline%20for%20cm-ui%20Pipeline/)
